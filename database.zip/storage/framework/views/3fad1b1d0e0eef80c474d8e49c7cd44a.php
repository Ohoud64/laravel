<?php $__env->startSection('content'); ?>



<div class="container">
      <div class="row">
        <div class="col">
        <h1 class="alert" style="background-color: #ABC4AA; color: white;">تفاصيل المنتجات</h1>

            <div class="card">
                <div class="card-body" style="background-color: #F5F5F5; color: black;">
                    <form action="<?php echo e(route('ccckkmm')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-4">
                            <label for="id_sel" class="form-label">رقم المنتج</label>
                            <select class="form-select" id="id_sel" name="id_sel" style="background-color: #A9907E; color: white;">
                                <?php $__currentLoopData = $podg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hoo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($hoo->id); ?>"><?php echo e($hoo->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <label for="fg1" class="form-label">سعر المنتج</label>
                                <input type="text" class="form-control" id="fg1" name="fg1" style="background-color: #A9907E; color: white;">
                            </div>
                            <div class="col">
                            <label for="fg2" class="form-label">الكمية</label>
                            <input type="text" class="form-control" id="fg2" name="fg2" style="background-color: #A9907E; color: white;">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col">
                                <label for="fg4" class="form-label">لون المنتج</label>
                                <input type="text" class="form-control" id="fg4" name="fg4" style="background-color: #A9907E; color: white;">
                            </div>
                            <div class="col">
                            <label for="fg3" class="form-label"> صورة المنتج</label>
                            <input type="text" class="form-control" id="fg3" name="fg3" style="background-color: #A9907E; color: white;">
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col text-center">
                            <button class="btn " style="background-color: #ABC4AA; color: white;">حفظ</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      </div>


      <div class="row mt-5">
    <div class="col">
        <div class="card">
            <div class="card-body " style="background-color: #F5F5F5; color: white;">
                <table class="table text-center">
                    <thead>
                        <tr>
                            <th>رقم المنتج</th>
                            <th>اسم المنتج</th>
                            <th>سعر المنتج</th>
                            <th>الكمية </th>
                            <th>صورة المنتج</th>
                            <th>لون المنتج</th>
                            <th colspan="2">اجراء</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $podmkk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ivvv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                            <?php echo e($ivvv->id); ?>

                            </td>
                            <td>
                            <?php echo e($ivvv->name); ?>

                            </td>
                            <td>
                            <?php echo e($ivvv->price); ?>

                            </td>
                            <td>
                            <?php echo e($ivvv->qty); ?>

                            </td>
                            <td>
                            <?php echo e($ivvv->img); ?>

                            </td>
                            <td>
                            <?php echo e($ivvv->color); ?>

                            </td>
                            <td>
                           <a href="#" onclick="lunch(<?php echo e($ivvv->id); ?>)"><i class="bi bi-trash3 text-danger"></i></a>
                            </td>
                            <td>
                            <a href="<?php echo e(route('kmlr',['ed'=>$ivvv->id])); ?>"> <i class="bi bi-pencil-square text-success"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>


  
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appdash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\shopping\resources\views/dashboard/product_details.blade.php ENDPATH**/ ?>