<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row mt-5">
        <div class="col">
           <?php $__currentLoopData = $gk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ded): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="row mt-3">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <div class="row mt-3">
                            <div class="col">
                              <img src="https://rukminim1.flixcart.com/image/1664/1664/gamingconsole/g/a/t/playstation-4-ps4-500-sony-dualshock-4-controller-original-imadrhehpvvetkgf.jpeg?q=90" wedith="200" height="200">
                              <img src="https://th.bing.com/th/id/OIP.YEqIOqhGxyfrNGi3oUZ0eQHaEn?rs=1&pid=ImgDetMain" wedith="200" height="200">

                            </div>
                            <div class="col">
                                <h1 class="alert alert-success"><?php echo e($ded->name); ?></h1>
                                <p ><?php echo e($ded->description); ?></p>
                            </div>                    
                        </div>

                        <div class="row">
                            <div class="col text-center">
                                <a href="<?php echo e(route('pnbp',['id'=>$ded->id])); ?>" class="btn btn-primary">تفاصيل</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appuserui', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\shopping\resources\views/userinterface/play.blade.php ENDPATH**/ ?>